import gurobipy
import numpy as np
import random
from decimal import Decimal
import scipy.stats as stats  #
from decimal import Decimal

t = 0.5  # Threshold

# Log-normal distribution
# mu： mean
# sigma: Variance
# return: d
def logNormalDistribution(mu, sigma, v_len):
    mu = mu - 0.95
    x = np.linspace(0, 1, 1000)
    y = stats.lognorm.pdf(x, s=sigma, loc=mu)

    # ln = stats.lognorm.pdf(x,s = 1, loc = 0,scale=std)

    maxy = 0
    for i in y:
        if i > maxy:
            maxy = i
    for i in range(len(y)):
        y[i] = y[i] / maxy
    sumy = sum(y)
    for i in range(len(y)):
        y[i] = y[i] / sumy
    v = np.arange(1, 1001, 1000 / (v_len - 1))
    vList = []
    for i in v:
        vList.append(int(i))
    vList.append(999)
    l = []
    for i in vList:
        l.append(y[i])
    sumL = sum(l)
    for i in range(len(l)):
        l[i] = l[i] / sumL
    return l

#Generate the r matrix from d.
def logNormalDistR(SD, v_len):
    if SD <= 0.01:
        SD = 0.01
    r = np.zeros((v_len, v_len))

    for i in range(v_len):
        r[i] = logNormalDistribution(i / (v_len - 1), SD, v_len)
    return r


# normal distribution
# Input the mean, standard deviation, and the number of generated
# Output Discrete Normal distribution
def normalDistribution(mean, std, v_len):
    normalDist = stats.norm(mean, std)
    x = np.arange(0, 1, 0.001)
    y = normalDist.pdf(x)
    maxy = 0
    for i in y:
        if i > maxy:
            maxy = i
    for i in range(len(y)):
        y[i] = y[i] / maxy
    sumy = sum(y)
    for i in range(len(y)):
        y[i] = y[i] / sumy
    v = np.arange(0, 1000, 1000 / (v_len - 1))
    vList = []
    for i in v:
        vList.append(int(i))
    vList.append(999)
    l = []
    for i in vList:
        l.append(y[i])
    sumL = sum(l)
    for i in range(len(l)):
        l[i] = l[i] / sumL
    return l

#Generate the normal distribution for d
def normalDistD(peak, SD, v_len):
    return normalDistribution(peak, SD, v_len)

#Generate the normal distribution for r
def normalDistR(SD, v_len):
    r = np.zeros((v_len, v_len))
    for i in range(v_len):
        r[i] = normalDistribution(i / (v_len - 1), SD, v_len)
    return r

# distribution of V
# The minimum value is 0 and the maximum value is 1, where each value is spaced at a 1 over number-1 interval
def functionV(number):
    d = np.zeros(number)

    for i in range(number):
        d[i] = i / (number - 1)

    d[number - 1] = 1.0

    return d


#Omniscient Mechanism
#Input  matrix R
#       support of V
#       probability distributio D
#Output Collector's Objective
#       matrix X
def OM(r, v_len, d):
    v = functionV(v_len)
    MODEL0 = gurobipy.Model()

    x = MODEL0.addVars(range(0, v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='x')

    MODEL0.update()

    #set objective
    MODEL0.setObjective(gurobipy.quicksum((v[i] - t) * d[i] *
                                          gurobipy.quicksum(x[i * v_len + j] for j in range(0, v_len))
                                          for i in range(0, v_len)),
                        gurobipy.GRB.MAXIMIZE)

    #x(v,s) \in [0,1]
    for i in range(0, v_len * v_len):
        MODEL0.addConstr(x[i] <= 1)
        MODEL0.addConstr(x[i] >= 0)

    # Execution of linear programming models
    MODEL0.optimize()

    # Output model results
    o0 = MODEL0.objVal
    print("Objective for Omniscient Mechanism:", o0)
    print("X for Omniscient Mechanism：")
    x_list = []
    j = 0
    for v in MODEL0.getVars():

        print('%10s' % round(v.x, 5), end="")
        print(",", end="")
        x_list.append(v.x)
        if (j == v_len - 1):
            print(" ")
            j = 0
        else:
            j = j + 1
    return o0, x_list


#Score Only Mechanism
#Input  matrix R
#       support of V
#       probability distributio D
#Output Collector's Objective
#       matrix X
def SOM(r, v_len, d):
    v = functionV(v_len)
    MODEL1 = gurobipy.Model()

    x = MODEL1.addVars(range(0, v_len * v_len), vtype=gurobipy.GRB.BINARY, name='x')

    MODEL1.update()
    # set objective
    MODEL1.setObjective(gurobipy.quicksum((v[i] - t) * d[i] *
                                          gurobipy.quicksum(x[i * v_len + j] * r[i][j] for j in range(0, v_len))
                                          for i in range(0, v_len)),
                        gurobipy.GRB.MAXIMIZE)
    # x(v,s) \in [0,1]
    for i in range(0, v_len * v_len):
        MODEL1.addConstr(x[i] <= 1)
        MODEL1.addConstr(x[i] >= 0)

    #x(v,\cdot) is depends on score
    for j in range(0, v_len):
        tem = 0
        for i in range(0, v_len):
            tem = tem + (v[i] - t) * r[i][j] * d[i]
            if tem >= 0 and i == v_len - 1:
                for k in range(0, v_len):
                    MODEL1.addConstr(x[k * v_len + j] >= 1)
            if tem < 0 and i == v_len - 1:
                for k in range(0, v_len):
                    MODEL1.addConstr(x[k * v_len + j] <= 0)

    # Execution of linear programming models
    MODEL1.optimize()

    # Output model results
    o1 = MODEL1.objVal
    print("Objective for Score Only Mechanism:", o1)
    print("X for Score Only Mechanism：")

    j = 0
    x_list = []
    for v in MODEL1.getVars():

        print('%10s' % round(v.x, 5), end="")
        x_list.append(v.x)
        print(",", end="")
        if (j == v_len - 1):
            print(" ")
            j = 0
        else:
            j = j + 1

    return o1, x_list



#Optimal Mechanism for k=1
#Input  matrix R
#       support of V
#       probability distributio D
#Output Collector's Objective
#       matrix X
def OM_1(r, v_len, d):
    v = functionV(v_len)
    MODEL2 = gurobipy.Model()

    x = MODEL2.addVars(range(0, v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='x')

    MODEL2.update()
    # set objective
    MODEL2.setObjective(gurobipy.quicksum((v[i] - t) * d[i] *
                                          gurobipy.quicksum(x[i * v_len + j] * r[i][j] for j in range(0, v_len))
                                          for i in range(0, v_len)),
                        gurobipy.GRB.MAXIMIZE)

    # x(v,s) \in [0,1]
    for i in range(0, v_len * v_len):
        MODEL2.addConstr(x[i] <= 1)
        MODEL2.addConstr(x[i] >= 0)

    # Guarantee the truthfulness
    for i in range(0, v_len):
        tem1 = 0
        for k1 in range(0, v_len):
            # sum_k1 x(v,s)*r(v,s)
            tem1 = tem1 + x[i * v_len + k1] * r[i][k1]
        for i2 in range(0, v_len):
            tem2 = 0
            # sum_k2 x(v',s)*r(v's)     (v!=v')
            for k2 in range(0, v_len):
                tem2 = tem2 + x[i2 * v_len + k2] * r[i][k2]
            MODEL2.addConstr(tem1 >= tem2)
            if i2 >= 1:# x(v,\cdot) monotone
                MODEL2.addConstr(x[i * v_len + i2] >= x[i * v_len + i2 - 1])

    # Execution of linear programming models
    MODEL2.optimize()

    # output the result
    o2 = MODEL2.objVal
    print("Objective for Optimal Mechanism 1:", o2)
    print("X for Optimal Mechanism 1：")

    j = 0
    x_list = []
    for v in MODEL2.getVars():

        print('%10s' % round(v.x, 5), end="")
        x_list.append(v.x)
        print(",", end="")
        if j == v_len - 1:
            print(" ")
            j = 0
        else:
            j = j + 1

    return o2, x_list


#Two Menu Mechanism
#Input  matrix R
#       support of V
#       probability distributio D
#Output Collector's Objective
#       matrix X
def TMM(r, v_len, d):
    M3maxObj = -1.0
    resultx = []

    for alpha in range(0, v_len - 1):
        for ones in range(alpha, v_len):
            alp = np.zeros((v_len))
            onesList = np.zeros((v_len))
            onesListOverAlp = np.zeros((v_len))
            for i in range(0, v_len):
                for j in range(alpha, v_len):
                    alp[i] = alp[i] + r[i][j]
                for j in range(ones, v_len):
                    onesList[i] = onesList[i] + r[i][j]
                onesListOverAlp[i] = onesList[i] / alp[i]

            location = np.argsort(onesListOverAlp)
            onesListOverAlpSoted = sorted(onesListOverAlp)

            for alpha_n in onesListOverAlpSoted:

                # Create Model
                MODEL3 = gurobipy.Model()

                # Create Variable
                x3 = MODEL3.addVars(range(0, v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='x3')
                count = 0
                v = functionV(v_len)

                # Update the variable environment
                MODEL3.update()

                # Create Objective
                MODEL3.setObjective(gurobipy.quicksum((v[i] - t) * d[i] *
                                                      gurobipy.quicksum(
                                                          x3[i * v_len + j] * r[i][j] for j in
                                                          range(v_len))
                                                      for i in range(v_len)),
                                    gurobipy.GRB.MAXIMIZE)

                # Creating constraints x(v,s) \in [0,1]
                for i in range(0, v_len * v_len):
                    MODEL3.addConstr(x3[i] <= 1)
                    MODEL3.addConstr(x3[i] >= 0)

                # Guarantee the two menu
                for i in range(v_len):
                    if onesListOverAlp[i] <= alpha_n:
                        for j in range(alpha, v_len):
                            MODEL3.addConstr(x3[i * v_len + j] <= alpha_n)
                            MODEL3.addConstr(x3[i * v_len + j] >= alpha_n)
                        for j in range(0, alpha):
                            MODEL3.addConstr(x3[i * v_len + j] <= 0)
                            MODEL3.addConstr(x3[i * v_len + j] >= 0)
                    else:
                        for j in range(ones, v_len):
                            MODEL3.addConstr(x3[i * v_len + j] >= 1)
                            MODEL3.addConstr(x3[i * v_len + j] <= 1)
                        for j in range(0, ones):
                            MODEL3.addConstr(x3[i * v_len + j] <= 0)
                            MODEL3.addConstr(x3[i * v_len + j] >= 0)

                # Execution of linear programming models
                MODEL3.optimize()

                # Output model results
                o3 = MODEL3.objVal
                print("Objective for Two Menu Mechanism:", o3)
                print("X for Two Menu Mechanism：")
                tem = []
                if o3 > M3maxObj:
                    M3maxObj = o3
                    M3maxAlpha = alpha_n
                    j = 0
                    for v in MODEL3.getVars():

                        print('%10s' % round(v.x, 5), end="")
                        tem.append(round(v.x, 5))
                        print(",", end="")
                        if (j == v_len - 1):
                            print(" ")
                            j = 0
                        else:
                            j = j + 1
                    resultx = tem
                print("b1 is：", alpha)
                print("b2 is：", ones)
                print("The alpha takes the value of：", alpha_n)

                MODEL3.terminate()


    if M3maxObj < 0:
        M3maxObj = 0
        for v in range(v_len):
            for s in range(v_len):
                resultx[v * v_len + s] = 0

    print("Objective for Optimal Two Menu Mechanism:", M3maxObj)
    print("X for Optimal Two Menu Mechanism：", resultx)
    return M3maxObj, resultx


#Optimal Union Mechanism for two items
#Input  matrix R
#       support of V
#       probability distributio D
#Output Collector's Objective
#       matrix X
def UMOPT(r, v_len, d):
    v_1 = functionV(v_len)
    v_2 = functionV(v_len)

    MODEL5 = gurobipy.Model()
    x = MODEL5.addVars(range(0, 2 * v_len * v_len * v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='x')
    y = MODEL5.addVars(range(0, 2 * v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='y')

    MODEL5.update()
    # set objective
    MODEL5.setObjective(gurobipy.quicksum(gurobipy.quicksum((v_1[i_1] - t) * d[i_1] * d[i_2] *
                                                            gurobipy.quicksum(gurobipy.quicksum(x[
                                                                                                    i_1 * v_len * v_len * v_len + i_2 * v_len * v_len + j_1 * v_len + j_2] *
                                                                                                r[i_1][j_1] *
                                                                                                r[i_2][
                                                                                                    j_2] for j_1 in
                                                                                                range(0, v_len)) for
                                                                              j_2 in range(0, v_len))
                                                            for i_1 in range(0, v_len)) for i_2 in range(0, v_len))
                        + gurobipy.quicksum(gurobipy.quicksum((v_2[i_2] - t) * d[i_1] * d[i_2] *
                                                              gurobipy.quicksum(
                                                                  gurobipy.quicksum(x[v_len * v_len * v_len * v_len +
                                                                                      i_1 * v_len * v_len * v_len + i_2 * v_len * v_len + j_1 * v_len + j_2] *
                                                                                    r[i_1][j_1] *
                                                                                    r[i_2][j_2] for
                                                                                    j_1
                                                                                    in
                                                                                    range(0, v_len))
                                                                  for j_2 in range(0, v_len))
                                                              for i_1 in range(0, v_len)) for i_2 in
                                            range(0, v_len))
                        ,
                        gurobipy.GRB.MAXIMIZE)
    # x(v1,v2,s1,s2) \in [0,1]
    for i in range(0, 2 * v_len * v_len):
        MODEL5.addConstr(y[i] <= 1)
        MODEL5.addConstr(y[i] >= 0)
    for i in range(0, 2 * v_len * v_len * v_len * v_len):
        MODEL5.addConstr(x[i] <= 1)
        MODEL5.addConstr(x[i] >= 0)

    #set Monotonicity
    for v1 in range(v_len):
        for v2 in range(v_len):
            for s1 in range(v_len):
                for s2 in range(v_len):
                    MODEL5.addConstr(y[v1 * v_len + s1] + y[v_len * v_len + v2 * v_len + s2] <= x[
                        v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2] + x[
                                         v_len * v_len * v_len * v_len + v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2])
                    MODEL5.addConstr(y[v1 * v_len + s1] + y[v_len * v_len + v2 * v_len + s2] >= x[
                        v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2] + x[
                                         v_len * v_len * v_len * v_len + v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2])
    # Guarantee the truthfulness
    for i in range(0, v_len):
        tem1 = 0
        tem3 = 0
        for k1 in range(0, v_len):
            # sum_k1 x(v,s)*r(v,s)
            tem1 = tem1 + y[i * v_len + k1] * r[i][k1]
            tem3 = tem3 + y[v_len * v_len + i * v_len + k1] * r[i][k1]

        for i2 in range(0, v_len):
            tem2 = 0
            tem4 = 0
            # sum_k2 x(v',s)*r(v's)     (v!=v')
            for k2 in range(0, v_len):
                tem2 = tem2 + y[i2 * v_len + k2] * r[i][k2]
                tem4 = tem4 + y[v_len * v_len + i2 * v_len + k2] * r[i][k2]
            MODEL5.addConstr(tem1 >= tem2)
            MODEL5.addConstr(tem3 >= tem4)
            if i2 >= 1:
                MODEL5.addConstr(y[i * v_len + i2] >= y[i * v_len + i2 - 1])
                MODEL5.addConstr(y[v_len * v_len + i * v_len + i2] >= y[v_len * v_len + i * v_len + i2 - 1])

    MODEL5.optimize()

    #Output model results
    o5 = MODEL5.objVal
    x5 = []
    print("Objective for Union Mechanism consists of two Optimal Mechanism 1:",o5)
    print("X for Union Mechanism consists of two Optimal Mechanism 1：")
    v1 = 0
    v2 = 0
    j = 0
    j2 = 0
    paper = 1
    for v in MODEL5.getVars():
        x5.append(round(v.x, 5))
        # twoPaperResult[v_1[v1]][v_2[v2]][j][j2] = round(v.x, 5)
        if paper < 3:
            if j2 == 0:
                if v1 == 0 and v2 == 0:
                    print("paper:", paper)
                print("value of v_1 is：", v_1[v1])
                print("value of v_2 is：", v_2[v2])
                print("value of [s1,s2] shown as follows：")
        else:
            print("paper:", paper)
        print('%10s' % round(v.x, 5), end="")
        print(",", end="")
        j2 = j2 + 1
        if (j2 == v_len * v_len):
            print(" ")
            j2 = 0
            v2 = v2 + 1
            if v2 == v_len:
                v2 = 0
                v1 = v1 + 1
                if v1 == v_len:
                    paper = paper + 1
                    v1 = 0
                    v2 = 0
                    j = -1
                    j2 = 0
        if (j == v_len - 1):
            print(" ")
            j = 0
        else:
            j = j + 1

    return o5, x5


#Union Mechanism consists of two Two Menu Mechanism
#Input  matrix R
#       support of V
#       probability distributio D
#       X from optimal Two Menu Mechanism
#Output Collector's Objective
#       matrix X
def UM_TMM(r, v_len, d, x3):
    v_1 = functionV(v_len)
    v_2 = functionV(v_len)

    MODEL5 = gurobipy.Model()
    x = MODEL5.addVars(range(0, 2 * v_len * v_len * v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='x')
    y = x3

    MODEL5.update()
    # set objective
    MODEL5.setObjective(gurobipy.quicksum(gurobipy.quicksum((v_1[i_1] - t) * d[i_1] * d[i_2] *
                                                            gurobipy.quicksum(gurobipy.quicksum(x[
                                                                                                    i_1 * v_len * v_len * v_len + i_2 * v_len * v_len + j_1 * v_len + j_2] *
                                                                                                r[i_1][j_1] *
                                                                                                r[i_2][
                                                                                                    j_2] for j_1 in
                                                                                                range(0, v_len)) for
                                                                              j_2 in range(0, v_len))
                                                            for i_1 in range(0, v_len)) for i_2 in range(0, v_len))
                        + gurobipy.quicksum(gurobipy.quicksum((v_2[i_2] - t) * d[i_1] * d[i_2] *
                                                              gurobipy.quicksum(
                                                                  gurobipy.quicksum(x[v_len * v_len * v_len * v_len +
                                                                                      i_1 * v_len * v_len * v_len + i_2 * v_len * v_len + j_1 * v_len + j_2] *
                                                                                    r[i_1][j_1] *
                                                                                    r[i_2][j_2] for
                                                                                    j_1
                                                                                    in
                                                                                    range(0, v_len))
                                                                  for j_2 in range(0, v_len))
                                                              for i_1 in range(0, v_len)) for i_2 in
                                            range(0, v_len))
                        ,
                        gurobipy.GRB.MAXIMIZE)
    # x(v1,v2,s1,s2) \in [0,1]
    for i in range(0, 2 * v_len * v_len * v_len * v_len):
        MODEL5.addConstr(x[i] <= 1)
        MODEL5.addConstr(x[i] >= 0)
    # set Monotonicity
    for v1 in range(v_len):
        for v2 in range(v_len):
            for s1 in range(v_len):
                for s2 in range(v_len):
                    MODEL5.addConstr(y[v1 * v_len + s1] + y[v2 * v_len + s2] <= x[
                        v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2] + x[
                                         v_len * v_len * v_len * v_len + v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2])
                    MODEL5.addConstr(y[v1 * v_len + s1] + y[v2 * v_len + s2] >= x[
                        v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2] + x[
                                         v_len * v_len * v_len * v_len + v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2])

    MODEL5.optimize()

    # 输出模型结果
    o5 = MODEL5.objVal
    x5 = []
    print("Objective for Union Mechanism consists of two Two Menu Mechanism:", o5)
    print("X for Union Mechanism consists of two Two Menu Mechanism：")
    v1 = 0
    v2 = 0
    j = 0
    j2 = 0
    paper = 1
    for v in MODEL5.getVars():
        x5.append(round(v.x, 5))
        # twoPaperResult[v_1[v1]][v_2[v2]][j][j2] = round(v.x, 5)
        if paper < 3:
            if j2 == 0:
                if v1 == 0 and v2 == 0:
                    print("paper:", paper)
                print("value of v_1 is：", v_1[v1])
                print("value of v_2 is：", v_2[v2])
                print("value of [s1,s2] is shown below：")
        else:
            print("paper:", paper)
        print('%10s' % round(v.x, 5), end="")
        print(",", end="")
        j2 = j2 + 1
        if (j2 == v_len * v_len):
            print(" ")
            j2 = 0
            v2 = v2 + 1
            if v2 == v_len:
                v2 = 0
                v1 = v1 + 1
                if v1 == v_len:
                    paper = paper + 1
                    v1 = 0
                    v2 = 0
                    j = -1
                    j2 = 0
        if (j == v_len - 1):
            print(" ")
            j = 0
        else:
            j = j + 1

    return o5, x5


#Optimal Mechanism 2
#Input  matrix R
#       support of V
#       probability distributio D
#Output Collector's Objective
#       matrix X
def OM_2(r, v_len, d):
    for run in range(1):

        v_1 = functionV(v_len)
        v_2 = functionV(v_len)

        MODEL4 = gurobipy.Model()
        # Create Variables
        x = MODEL4.addVars(range(0, v_len * v_len * v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='x')
        y = MODEL4.addVars(range(0, v_len * v_len * v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='y')
        d_1 = d
        d_2 = d_1
        # Update the variable environment
        MODEL4.update()

        # acceptation function x(v1,v2,s1,s2)
        # Create target function
        MODEL4.setObjective(gurobipy.quicksum(gurobipy.quicksum((v_1[i_1] - t) * d_1[i_1] * d_2[i_2] *
                                                                gurobipy.quicksum(gurobipy.quicksum(x[
                                                                                                        i_1 * v_len * v_len * v_len + i_2 * v_len * v_len + j_1 * v_len + j_2] *
                                                                                                    r[i_1][j_1] *
                                                                                                    r[i_2][
                                                                                                        j_2] for j_1 in
                                                                                                    range(0, v_len)) for
                                                                                  j_2 in range(0, v_len))
                                                                for i_1 in range(0, v_len)) for i_2 in range(0, v_len))
                            + gurobipy.quicksum(gurobipy.quicksum((v_2[i_2] - t) * d_1[i_1] * d_2[i_2] *
                                                                  gurobipy.quicksum(gurobipy.quicksum(y[
                                                                                                          i_1 * v_len * v_len * v_len + i_2 * v_len * v_len + j_1 * v_len + j_2] *
                                                                                                      r[i_1][j_1] *
                                                                                                      r[i_2][j_2] for
                                                                                                      j_1
                                                                                                      in
                                                                                                      range(0, v_len))
                                                                                    for j_2 in range(0, v_len))
                                                                  for i_1 in range(0, v_len)) for i_2 in
                                                range(0, v_len))
                            ,
                            gurobipy.GRB.MAXIMIZE)

        # Creating constraints
        # x(v1,v2,s1,s2) \in [0,1]
        for i in range(0, v_len * v_len * v_len * v_len):
            MODEL4.addConstr(x[i] <= 1)
            MODEL4.addConstr(x[i] >= 0)
            MODEL4.addConstr(y[i] <= 1)
            MODEL4.addConstr(y[i] >= 0)
        # Guarantee the truthfulness
        for i_1 in range(0, v_len):
            for i_2 in range(0, v_len):
                tem1 = 0
                for j_1 in range(0, v_len):
                    for j_2 in range(0, v_len):
                        # sum x(v1,v2,s1,s2)*r(v1,s1)*r(v2,s2)
                        tem1 = tem1 + x[i_1 * v_len * v_len * v_len + i_2 * v_len * v_len + j_1 * v_len + j_2] * r[i_1][
                            j_1] * r[i_2][j_2] + y[
                                   i_1 * v_len * v_len * v_len + i_2 * v_len * v_len + j_1 * v_len + j_2] * r[i_1][
                                   j_1] * r[i_2][j_2]

                for k_1 in range(0, v_len):
                    for k_2 in range(0, v_len):
                        tem2 = 0
                        for j_21 in range(0, v_len):
                            for j_22 in range(0, v_len):
                                tem2 = tem2 + x[
                                    k_1 * v_len * v_len * v_len + k_2 * v_len * v_len + j_21 * v_len + j_22] * \
                                       r[i_1][j_21] * r[i_2][j_22] + y[
                                           k_1 * v_len * v_len * v_len + k_2 * v_len * v_len + j_21 * v_len + j_22] * \
                                       r[i_1][j_21] * r[i_2][j_22]
                        MODEL4.addConstr(tem1 >= tem2)
        # Guarantee the Monotonicity
        for v1 in range(v_len):
            for v2 in range(v_len):
                for s1 in range(v_len):
                    for s2 in range(v_len):
                        if s1 > 0:
                            MODEL4.addConstr(x[v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2] >= x[
                                v1 * v_len * v_len * v_len + v2 * v_len * v_len + (s1 - 1) * v_len + s2])
                            MODEL4.addConstr(y[v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2] >= y[
                                v1 * v_len * v_len * v_len + v2 * v_len * v_len + (s1 - 1) * v_len + s2])
                        if s2 > 0:
                            MODEL4.addConstr(x[v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2] >= x[
                                v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2 - 1])
                            MODEL4.addConstr(y[v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2] >= y[
                                v1 * v_len * v_len * v_len + v2 * v_len * v_len + s1 * v_len + s2 - 1])

        # Execution of linear programming models
        MODEL4.optimize()

        o4 = MODEL4.objVal
        print("Objective for Optimal Mechanism 2:", o4)
        print("X for Optimal Mechanism 2：")
        v1 = 0
        v2 = 0
        j = 0
        j2 = 0
        x_list = []
        count =0
        for v in MODEL4.getVars():

            if (count ==v_len*v_len*v_len*v_len):
                break
            count = count+1
            x_list.append(round(v.x, 5))
            # twoPaperResult[v_1[v1]][v_2[v2]][j][j2] = round(v.x, 5)
            if j2 == 0:
                print("value of v_1 is：", v_1[v1])
                print("value of v_2 is：", v_2[v2])
                print("value of [s1,s2] is shown below：")
            print('%10s' % round(v.x, 5), end="")
            print(",", end="")
            j2 = j2 + 1
            if (j2 == v_len * v_len):
                print(" ")
                j2 = 0
                v2 = v2 + 1
                if v2 == v_len:
                    v2 = 0
                    v1 = v1 + 1
            if (j == v_len - 1):
                print(" ")
                j = 0
            else:
                j = j + 1

        MODEL4.terminate()
        return o4, x_list


#Optimal Mechanism 3
#Input  matrix R
#       support of V
#       probability distributio D
#Output Collector's Objective
#       matrix X
def OM_3(r, v_len, d):
    for run in range(1):
        v_1 = functionV(v_len)
        v_2 = functionV(v_len)
        v_3 = functionV(v_len)

        # Create Model
        MODEL4 = gurobipy.Model()  # 3 value model

        # Create Variable
        x = MODEL4.addVars(range(0, v_len * v_len * v_len * v_len * v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='x')
        y = MODEL4.addVars(range(0, v_len * v_len * v_len * v_len * v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='y')
        z = MODEL4.addVars(range(0, v_len * v_len * v_len * v_len * v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS, name='z')
        d_1 = d
        d_2 = d_1
        d_3 = d_1
        # Update the variable environment
        MODEL4.update()

        # acceptation function x(v1,v2,v3,s1,s2,s3)
        # Create target function
        MODEL4.setObjective(gurobipy.quicksum(gurobipy.quicksum(gurobipy.quicksum((v_1[i_1] - t) * d_1[i_1] * d_2[i_2] * d_3[i_3] *
                                                                gurobipy.quicksum(gurobipy.quicksum(gurobipy.quicksum(x[i_1 * v_len * v_len * v_len* v_len * v_len + i_2 * v_len * v_len* v_len * v_len + i_3 *v_len* v_len * v_len+ j_1 * v_len* v_len + j_2* v_len + j_3] *
                                                                                                    r[i_1][j_1] * r[i_2][j_2]* r[i_3][j_3] for j_1 in range(0, v_len)) for j_2 in range(0, v_len))for j_3 in range(0, v_len))
                                                                for i_1 in range(0, v_len)) for i_2 in range(0, v_len)) for i_3 in range(0, v_len))
                            + gurobipy.quicksum(gurobipy.quicksum(gurobipy.quicksum((v_2[i_2] - t) * d_1[i_1] * d_2[i_2] * d_3[i_3] *
                                                                gurobipy.quicksum(gurobipy.quicksum(gurobipy.quicksum(y[i_1 * v_len * v_len * v_len* v_len * v_len + i_2 * v_len * v_len* v_len * v_len + i_3 *v_len* v_len * v_len+ j_1 * v_len* v_len + j_2* v_len + j_3] *
                                                                                                    r[i_1][j_1] * r[i_2][j_2]* r[i_3][j_3] for j_1 in range(0, v_len)) for j_2 in range(0, v_len))for j_3 in range(0, v_len))
                                                                for i_1 in range(0, v_len)) for i_2 in range(0, v_len)) for i_3 in range(0, v_len))
                            + gurobipy.quicksum(gurobipy.quicksum(gurobipy.quicksum((v_3[i_3] - t) * d_1[i_1] * d_2[i_2] * d_3[i_3] *
                                                                gurobipy.quicksum(gurobipy.quicksum(gurobipy.quicksum(z[i_1 * v_len * v_len * v_len* v_len * v_len + i_2 * v_len * v_len* v_len * v_len + i_3 *v_len* v_len * v_len+ j_1 * v_len* v_len + j_2* v_len + j_3] *
                                                                                                    r[i_1][j_1] * r[i_2][j_2]* r[i_3][j_3] for j_1 in range(0, v_len)) for j_2 in range(0, v_len))for j_3 in range(0, v_len))
                                                                for i_1 in range(0, v_len)) for i_2 in range(0, v_len)) for i_3 in range(0, v_len))
                            , gurobipy.GRB.MAXIMIZE)


        #Creating constraints
        # x(v1,v2,v3,s1,s2,s3) \in [0,1]
        for i in range(0, v_len * v_len * v_len * v_len * v_len * v_len):
            MODEL4.addConstr(x[i] <= 1)
            MODEL4.addConstr(x[i] >= 0)
            MODEL4.addConstr(y[i] <= 1)
            MODEL4.addConstr(y[i] >= 0)
            MODEL4.addConstr(z[i] <= 1)
            MODEL4.addConstr(z[i] >= 0)
        # Guarantee the truthfulness
        for i_1 in range(0, v_len):
            for i_2 in range(0, v_len):
                for i_3 in range(0,v_len):
                    temx = 0

                    for j_1 in range(0, v_len):
                        for j_2 in range(0, v_len):
                            for j_3 in range(0, v_len):

                                # sum x(v1,v2,v3,s1,s2,s3)*r(v1,s1)*r(v2,s2)*r(v3,s3)
                                temx = temx + x[i_1 * v_len * v_len * v_len* v_len * v_len + i_2 * v_len * v_len* v_len * v_len + i_3 *v_len* v_len * v_len+ j_1 * v_len* v_len + j_2* v_len + j_3] * r[i_1][j_1] * r[i_2][j_2]* r[i_3][j_3] + y[
                                    i_1 * v_len * v_len * v_len * v_len * v_len + i_2 * v_len * v_len * v_len * v_len + i_3 * v_len * v_len * v_len + j_1 * v_len * v_len + j_2 * v_len + j_3] * \
                                       r[i_1][j_1] * r[i_2][j_2] * r[i_3][j_3]  + z[
                                    i_1 * v_len * v_len * v_len * v_len * v_len + i_2 * v_len * v_len * v_len * v_len + i_3 * v_len * v_len * v_len + j_1 * v_len * v_len + j_2 * v_len + j_3] * \
                                       r[i_1][j_1] * r[i_2][j_2] * r[i_3][j_3]

                    for k_1 in range(0, v_len):
                        for k_2 in range(0, v_len):
                            for k_3 in range(0, v_len):

                                temx2 = 0
                                for j_21 in range(0, v_len):
                                    for j_22 in range(0, v_len):
                                        for j_23 in range(0, v_len):
                                            temx2 = temx2 + x[k_1 * v_len * v_len * v_len * v_len * v_len + k_2 * v_len * v_len * v_len * v_len + k_3 * v_len * v_len *v_len + j_21 * v_len * v_len + j_22 * v_len + j_23] * r[i_1][j_21] * r[i_2][j_22] * r[i_3][j_23]  + y[
                                                k_1 * v_len * v_len * v_len * v_len * v_len + k_2 * v_len * v_len * v_len * v_len + k_3 * v_len * v_len * v_len + j_21 * v_len * v_len + j_22 * v_len + j_23] * \
                                                    r[i_1][j_21] * r[i_2][j_22] * r[i_3][j_23] + z[
                                                k_1 * v_len * v_len * v_len * v_len * v_len + k_2 * v_len * v_len * v_len * v_len + k_3 * v_len * v_len * v_len + j_21 * v_len * v_len + j_22 * v_len + j_23] * \
                                                    r[i_1][j_21] * r[i_2][j_22] * r[i_3][j_23]
                                MODEL4.addConstr(temx >= temx2)
        # Guarantee the Monotonicity
        for v1 in range(v_len):
            for v2 in range(v_len):
                for v3 in range(v_len):
                    for s1 in range(v_len):
                        for s2 in range(v_len):
                            for s3 in range(v_len):
                                if s1 > 0:
                                    MODEL4.addConstr(x[v1 * v_len * v_len * v_len* v_len * v_len + v2 * v_len * v_len* v_len * v_len +v3 * v_len * v_len *v_len + s1 * v_len* v_len + s2* v_len + s3]
                                                     >= x[v1 * v_len * v_len * v_len* v_len * v_len + v2 * v_len * v_len* v_len * v_len +v3 * v_len * v_len *v_len + (s1-1) * v_len* v_len + s2* v_len + s3])
                                    MODEL4.addConstr(y[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + s1 * v_len * v_len + s2 * v_len + s3]
                                                     >= y[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + (
                                                                     s1 - 1) * v_len * v_len + s2 * v_len + s3])
                                    MODEL4.addConstr(z[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + s1 * v_len * v_len + s2 * v_len + s3]
                                                     >= z[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + (
                                                                     s1 - 1) * v_len * v_len + s2 * v_len + s3])
                                if s2 > 0:
                                    MODEL4.addConstr(x[v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + s1 * v_len * v_len + s2 * v_len + s3]
                                                     >= x[v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len +
                                                                     s1 * v_len * v_len + (s2 -1)* v_len + s3])
                                    MODEL4.addConstr(y[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + s1 * v_len * v_len + s2 * v_len + s3]
                                                     >= y[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len +
                                                         s1 * v_len * v_len + (s2 - 1) * v_len + s3])
                                    MODEL4.addConstr(z[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + s1 * v_len * v_len + s2 * v_len + s3]
                                                     >= z[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len +
                                                         s1 * v_len * v_len + (s2 - 1) * v_len + s3])
                                if s3 > 0:
                                    MODEL4.addConstr(x[v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + s1 * v_len * v_len + s2 * v_len + s3]
                                                     >= x[v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len +
                                                                     s1 * v_len * v_len + s2 * v_len + s3 -1])
                                    MODEL4.addConstr(y[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + s1 * v_len * v_len + s2 * v_len + s3]
                                                     >= y[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len +
                                                         s1 * v_len * v_len + s2 * v_len + s3 - 1])
                                    MODEL4.addConstr(z[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + s1 * v_len * v_len + s2 * v_len + s3]
                                                     >= z[
                                                         v1 * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len +
                                                         s1 * v_len * v_len + s2 * v_len + s3 - 1])

        # Execution of linear programming models
        MODEL4.optimize()
        # Output model results
        o4 = MODEL4.objVal
        x_list = []
        y_list = []
        z_list = []
        count =0
        for v in MODEL4.getVars():
            x_list.append(round(v.x, 5))

        MODEL4.terminate()
        print("Objective for Optimal Mechanism 3:", o4)
        return o4,x_list


#Ranking Mechanism
#Input  matrix R
#       support of V
#       probability distributio D
def M10_paperRanking(r, v_len, d):
    v = functionV(v_len)
    As = np.zeros((v_len, v_len))
    Ae = np.zeros((v_len, v_len))
    Ag = np.zeros((v_len, v_len))
    Bs = np.zeros((v_len, v_len))
    Be = np.zeros((v_len, v_len))
    Bg = np.zeros((v_len, v_len))

    for s1 in range(0, v_len):
        for s2 in range(0, v_len):
            AStem1 = 0
            AStem2 = 0
            AStem3 = 0
            for v1 in range(0, v_len):
                for v2 in range(0, v_len):
                    if v1 < v2:
                        AStem1 = AStem1 + v[v1] * d[v1] * d[v2] * r[v1, s1] * r[v2, s2]
                        AStem2 = AStem2 + d[v1] * d[v2] * r[v1, s1] * r[v2, s2]
                        AStem3 = AStem3 + v[v2] * d[v1] * d[v2] * r[v1, s1] * r[v2, s2]
            As[s1][s2] = AStem1 / AStem2
            Bg[s1][s2] = AStem3 / AStem2

            AEtem1 = 0
            AEtem2 = 0
            AEtem3 = 0
            for v1 in range(0, v_len):
                for v2 in range(0, v_len):
                    if v1 == v2:
                        AEtem1 = AEtem1 + v[v1] * d[v1] * d[v2] * r[v1, s1] * r[v2, s2]
                        AEtem2 = AEtem2 + d[v1] * d[v2] * r[v1, s1] * r[v2, s2]
                        AEtem3 = AEtem3 + v[v2] * d[v1] * d[v2] * r[v1, s1] * r[v2, s2]
            Ae[s1][s2] = AEtem1 / AEtem2
            Be[s1][s2] = AEtem3 / AEtem2

            AGtem1 = 0
            AGtem2 = 0
            AGtem3 = 0
            for v1 in range(0, v_len):
                for v2 in range(0, v_len):
                    if v1 > v2:
                        AGtem1 = AGtem1 + v[v1] * d[v1] * d[v2] * r[v1, s1] * r[v2, s2]
                        AGtem2 = AGtem2 + d[v1] * d[v2] * r[v1, s1] * r[v2, s2]
                        AGtem3 = AGtem3 + v[v2] * d[v1] * d[v2] * r[v1, s1] * r[v2, s2]
            Ag[s1][s2] = AGtem1 / AGtem2
            Bs[s1][s2] = AGtem3 / AGtem2

    print("As:")
    print(As)
    print("Bg:")
    print(Bg)
    print("Ae:")
    print(Ae)
    print("Be:")
    print(Be)
    print("Ag:")
    print(Ag)
    print("Bs:")
    print(Bs)

    for i1 in range(v_len):
        for i2 in range(v_len):
            if As[i1][i2] >= 0.5:
                As[i1][i2] = 1
            else:
                As[i1][i2] = 0

            if Bs[i1][i2] >= 0.5:
                Bs[i1][i2] = 1
            else:
                Bs[i1][i2] = 0

            if Ae[i1][i2] >= 0.5:
                Ae[i1][i2] = 1
            else:
                Ae[i1][i2] = 0

            if Be[i1][i2] >= 0.5:
                Be[i1][i2] = 1
            else:
                Be[i1][i2] = 0

            if Ag[i1][i2] >= 0.5:
                Ag[i1][i2] = 1
            else:
                Ag[i1][i2] = 0

            if Bg[i1][i2] >= 0.5:
                Bg[i1][i2] = 1
            else:
                Bg[i1][i2] = 0


    print("As:")
    print(As)
    print("Bg:")
    print(Bg)
    print("Ae:")
    print(Ae)
    print("Be:")
    print(Be)
    print("Ag:")
    print(Ag)
    print("Bs:")
    print(Bs)

    x1g = np.zeros((v_len, v_len))
    x1e = np.zeros((v_len, v_len))
    x1s = np.zeros((v_len, v_len))

    for v1 in range(0, v_len):
        for v2 in range(0, v_len):
            for s1 in range(0, v_len):
                for s2 in range(0, v_len):
                    x1g[v1][v2] = x1g[v1][v2] + r[v1][s1] * r[v2][s2] * Ag[s1][s2] + r[v1][s1] * r[v2][s2] * Bs[s1][s2]
                    x1e[v1][v2] = x1e[v1][v2] + r[v1][s1] * r[v2][s2] * Ae[s1][s2] + r[v1][s1] * r[v2][s2] * Be[s1][s2]
                    x1s[v1][v2] = x1s[v1][v2] + r[v1][s1] * r[v2][s2] * As[s1][s2] + r[v1][s1] * r[v2][s2] * Bg[s1][s2]

    print("x1g:")
    print(x1g)
    print("x1e:")
    print(x1e)
    print("x1s:")
    print(x1s)

v_len = 7
v = functionV(v_len)
count =1
for count in range(count):
    d = logNormalDistribution(0.3, 0.25, v_len)
    r = logNormalDistR(0.25, v_len)
    for i in range(v_len):
        d[i] = round(d[i], 4)
        for j in range(v_len):
            r[i][j] = round(r[i][j], 4)
    # o0 = OM(r,v_len,d)
    o1, x1 = SOM(r, v_len, d)
    o2, x2 = OM_1(r, v_len, d)
    o3, x3 = TMM(r, v_len, d)
    o4, x4 = OM_2(r, v_len, d)
    o5, x5 = UMOPT(r, v_len, d)
    o5_3, x5_3 = UM_TMM(r, v_len, d, x3)
    om_3, xom_3 = OM_3(r, v_len, d)

    acc1 = np.zeros(v_len)
    acc2 = np.zeros(v_len)
    acc3 = np.zeros(v_len)
    acc4 = np.zeros(v_len)
    acc52 = np.zeros(v_len)
    acc53 = np.zeros(v_len)
    accom_3 = np.zeros(v_len)

    # print("Objective for Omniscient Mechanism:",o0)
    print("Objective for Score Only Mechanism：", o1)
    print("Objective for Optimal Mechanism 1：", o2)
    print("Objective for Two Menu Mechanism：", o3)
    print("Objective for Optimal Mechanism 2：", o4)
    print("Optimal Union Mechanism for two items：", o5)
    print("Union Mechanism consists of two Two Menu Mechanism：", o5_3)
    print("Objective for Optimal Mechanism 3：", om_3)

    for v in range(v_len):
        for s in range(v_len):
            acc1[v] = np.round(acc1[v] + x1[v * v_len + s] * r[v][s], 4)
            acc2[v] = np.round(acc2[v] + x2[v * v_len + s] * r[v][s], 4)
            acc3[v] = np.round(acc3[v] + x3[v * v_len + s] * r[v][s], 4)
            for v2 in range(v_len):
                for s2 in range(v_len):
                    for v3 in range(v_len):
                        for s3 in range(v_len):
                            accom_3[v] = np.round(accom_3[v] + xom_3[
                                v * v_len * v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len * v_len + v3 * v_len * v_len * v_len + s * v_len * v_len + s2 * v_len + s3] *
                                                  r[v][s] * \
                                                  r[v2][s2] * r[v3][s3] * d[v2] * d[v3], 4)
                    acc4[v] = np.round(
                        acc4[v] + x4[v * v_len * v_len * v_len + v2 * v_len * v_len + s * v_len + s2] * r[v][s] * \
                        r[v2][s2] * d[v2], 4)
                    acc52[v] = np.round(
                        acc52[v] + x5[v * v_len * v_len * v_len + v2 * v_len * v_len + s * v_len + s2] * r[v][
                            s] * r[v2][s2] * d[v2] + x5[
                            v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len + v * v_len * v_len + s2 * v_len + s] * \
                        r[v][s] * r[v2][s2] * d[v2], 4)
                    acc53[v] = np.round(
                        acc53[v] + x5_3[v * v_len * v_len * v_len + v2 * v_len * v_len + s * v_len + s2] * r[v][
                            s] * r[v2][s2] * d[v2] + x5_3[
                            v_len * v_len * v_len * v_len + v2 * v_len * v_len * v_len + v * v_len * v_len + s2 * v_len + s] * \
                        r[v][s] * r[v2][s2] * d[v2], 4)

    f = open('log.txt', 'a')
    print(str(np.round(o1, 4)) + " " + str(np.round(o2, 4)) + " " + str(np.round(o3, 4)) + " " + str(
        np.round(o4, 4)) + " " + str(np.round(o5, 4)) + " " + str(np.round(o5_3, 4)) + " " + str(np.round(om_3, 4)),
          file=f)
    f.close()

    f = open('log2.txt', 'a')
    print(str(acc1) + " " + str(acc2) + " " + str(acc3) + " " + str(acc4) + " " + str(acc52) + " " + str(
        acc53) + " " + str(accom_3), file=f)
    f.close()

    print("Turns：")
    print(count)
import gurobipy
import numpy as np
import random
from decimal import Decimal
import scipy.stats as stats  # Module containing statistical analysis functions
from decimal import Decimal

t = 0.5  # Threshold value


# Merge two arrays by combining them with addition of last element of first array and first element of second array
def merge_arrays(arr1, arr2):
    merged_array = [0] * (len(arr1) + len(arr2) - 1)  # Initialize merged array

    # Copy elements from first array
    for i in range(len(arr1)):
        merged_array[i] = arr1[i]

    # Add last element of first array and first element of second array
    merged_array[len(arr1) - 1] = arr1[-1] + arr2[0]

    # Copy remaining elements from second array (excluding first element)
    for i in range(1, len(arr2)):
        merged_array[i + len(arr1) - 1] = arr2[i]

    return merged_array


# Halve all values in an array
def halve_array(arr):
    for i in range(len(arr)):
        arr[i] = arr[i] / 2
    return arr


# Extract last n elements excluding last m elements from array
def get_last_n_but_m_elements(arr, m, n):
    if n >= len(arr) - m:
        return arr[:-m] if m > 0 else arr[-n:]
    else:
        return arr[-m - n:-m] if m > 0 else arr[-n:]


# Generate geometric distribution probability mass function
def geometric_distribution(p, n):
    prob_mass = []
    for i in range(n):
        prob_mass.append((1 - p) ** (i) * p)
    return prob_mass


# Modified geometric distribution generator
# :param p: Success probability per trial
# :param m: Peak value position
# :param n: Number of values to generate
# :return: Probability mass function list for modified geometric distribution
def geometricDistribution(p, m, n):
    prob_mass2 = geometric_distribution(p, n)

    # Create mirrored and combined distribution
    prob_mass2_flipped = prob_mass2[::-1]
    prob_mass2_full = merge_arrays(prob_mass2_flipped, prob_mass2)
    prob_mass2_full = halve_array(prob_mass2_full)
    prob_mass2_full = get_last_n_but_m_elements(prob_mass2_full, m, n)

    # Normalize probabilities to sum to 1
    prob_sum = sum(prob_mass2_full)
    if prob_sum == 0:
        return prob_mass2_full

    return [i / prob_sum for i in prob_mass2_full]


# Generate R matrix for geometric distribution
# :param p: Prediction accuracy probability
# :param v_len: Number of values to generate
# :return: R matrix of geometric distribution probabilities
def geometricDistR(p, v_len):
    r = np.zeros((v_len, v_len))
    for i in range(v_len):
        r[i] = geometricDistribution(p, i, v_len)
    return r


# Generate log-normal distribution
# :param mu: Mean (adjusted by -0.95)
# :param sigma: Standard deviation
# :param v_len: Number of values to generate
# :return: Log-normal distribution probabilities
def logNormalDistribution(mu, sigma, v_len):
    mu = mu - 0.95
    x = np.linspace(0, 1, 1000)
    y = stats.lognorm.pdf(x, s=sigma, loc=mu)

    # Normalize and process distribution
    maxy = max(y)
    y_normalized = [i / maxy for i in y]
    sumy = sum(y_normalized)
    y_normalized = [i / sumy for i in y_normalized]

    # Create sampling points
    v = np.arange(1, 1001, 1000 / (v_len - 1))
    vList = [int(i) for i in v] + [999]

    # Extract and normalize samples
    l = [y_normalized[i] for i in vList]
    sumL = sum(l)
    return [i / sumL for i in l]


# Generate R matrix for log-normal distribution
def logNormalDistR(SD, v_len):
    if SD <= 0.01:
        SD = 0.01
    r = np.zeros((v_len, v_len))
    for i in range(v_len):
        r[i] = logNormalDistribution(i / (v_len - 1), SD, v_len)
    return r


# Generate normal distribution probabilities
# :param mean: Distribution mean
# :param std: Standard deviation
# :param v_len: Number of values to generate
def normalDistribution(mean, std, v_len):
    normalDist = stats.norm(mean, std)
    x = np.arange(0, 1, 0.001)
    y = normalDist.pdf(x)

    # Normalize and process
    maxy = max(y)
    y_normalized = [i / maxy for i in y]
    sumy = sum(y_normalized)
    y_normalized = [i / sumy for i in y_normalized]

    # Create sampling points
    v = np.arange(0, 1000, 1000 / (v_len - 1))
    vList = [int(i) for i in v] + [999]

    # Extract and normalize samples
    l = [y_normalized[i] for i in vList]
    sumL = sum(l)
    return [i / sumL for i in l]


# Generate D matrix for normal distribution
def normalDistD(peak, SD, v_len):
    return normalDistribution(peak, SD, v_len)


# Generate R matrix for normal distribution
def normalDistR(SD, v_len):
    r = np.zeros((v_len, v_len))
    for i in range(v_len):
        r[i] = normalDistribution(i / (v_len - 1), SD, v_len)
    return r


# Generate single peak R matrix
def singelPeakR(len):
    r = np.zeros((len, len))
    for i in range(len):
        while True:
            r[i] = genPeakList(len, i)
            if peakAt(r[i], i):
                break
    return r


# Generate n random numbers that sum to 1
def sumOne(n):
    values = [0.0, 1000.0] + [random.randint(0, 1000) for _ in range(n - 1)]
    values.sort()
    intervals = [values[i + 1] - values[i] for i in range(n)]
    return [i / 1000.0 for i in intervals]


# Generate review score distribution R matrix
def functionR(len):
    r = np.zeros((len, len))
    for i in range(len):
        r[i] = sumOne(len)
    return r


# Generate value distribution D
def functionD(number):
    return sumOne(number)


# Generate value array V
def functionV(number):
    d = np.zeros(number)
    for i in range(number):
        d[i] = i / (number - 1)
    d[number - 1] = 1.0
    return d


# Check if distribution is single-peaked
def isSingelPeak(d):
    flag = 0  # 0: left of peak, 1: right of peak
    pre = 0
    for i in d:
        if i <= pre and flag == 1:
            pre = i
            continue
        if i <= pre and flag == 0:
            pre = i
            flag = 1
            continue
        if i >= pre and flag == 0:
            pre = i
            continue
        if i >= pre and flag == 1:
            return 0
    return 1


# Check R matrix monotonicity
def monotonous(r, v_len):
    for j in range(v_len):
        if not isSingelPeak(r[j]):
            return 0
        if not isMax(r[j], j):
            return 0
    return 1


# Check if nth element is maximum in list
def isMax(l, n):
    return l[n] == max(l)


# Check if peak is at specific position
def peakAt(d, n):
    return isSingelPeak(d) and isMax(d, n)


# Check matrix monotonicity
def isMono(r, n):
    for i in range(n):
        sum_pre = 1
        for j in range(n):
            current_sum = sum(r[j][:i + 1])
            if current_sum > sum_pre:
                return 0
            sum_pre = current_sum
    return 1


# Generate peak-aligned probability list
def genPeakList(len, i):
    while True:
        l = sumOne(len)
        if peakAt(l, i) and l[i] >= 0.5:
            return l


# Generate monotonic single-peak matrix
def genMonoPeak(n):
    r = np.zeros((n, n))
    while True:
        for i in range(n):
            r[i] = genPeakList(n, i)
        if isMono(r, n):
            return r


# Optimization Model 0
def M0(r, v_len, d):
    v = functionV(v_len)
    MODEL0 = gurobipy.Model()
    x = MODEL0.addVars(range(v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS)

    # Set objective function
    MODEL0.setObjective(gurobipy.quicksum(
        (v[i] - t) * d[i] * gurobipy.quicksum(x[i * v_len + j] for j in range(v_len))
        for i in range(v_len)), gurobipy.GRB.MAXIMIZE
    )

    # Add constraints
    for i in range(v_len * v_len):
        MODEL0.addConstr(x[i] <= 1)
        MODEL0.addConstr(x[i] >= 0)

    MODEL0.optimize()
    return MODEL0.objVal


# Second Optimization Model
def SO(r, v_len, d):
    v = functionV(v_len)
    MODEL1 = gurobipy.Model()
    x = MODEL1.addVars(range(v_len * v_len), vtype=gurobipy.GRB.BINARY)

    # Set objective function
    MODEL1.setObjective(gurobipy.quicksum(
        (v[i] - t) * d[i] * gurobipy.quicksum(x[i * v_len + j] * r[i][j] for j in range(v_len))
        for i in range(v_len)), gurobipy.GRB.MAXIMIZE
    )

    # Add constraints
    for i in range(v_len * v_len):
        MODEL1.addConstr(x[i] <= 1)
        MODEL1.addConstr(x[i] >= 0)

    for j in range(v_len):
        tem = sum((v[i] - t) * r[i][j] * d[i] for i in range(v_len))
        if tem >= 0:
            for k in range(v_len):
                MODEL1.addConstr(x[k * v_len + j] >= 1)
        else:
            for k in range(v_len):
                MODEL1.addConstr(x[k * v_len + j] <= 0)

    MODEL1.optimize()
    return MODEL1.objVal, [v.x for v in MODEL1.getVars()]


# Optimization Model 2
def M2(r, v_len, d):
    v = functionV(v_len)
    MODEL2 = gurobipy.Model()
    x = MODEL2.addVars(range(v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS)

    # Set objective function
    MODEL2.setObjective(gurobipy.quicksum(
        (v[i] - t) * d[i] * gurobipy.quicksum(x[i * v_len + j] * r[i][j] for j in range(v_len))
        for i in range(v_len)), gurobipy.GRB.MAXIMIZE
    )

    # Add constraints
    for i in range(v_len * v_len):
        MODEL2.addConstr(x[i] <= 1)
        MODEL2.addConstr(x[i] >= 0)

    for i in range(v_len):
        for i2 in range(v_len):
            MODEL2.addConstr(
                gurobipy.quicksum(x[i * v_len + k] * r[i][k] for k in range(v_len)) >=
                gurobipy.quicksum(x[i2 * v_len + k] * r[i][k] for k in range(v_len))
            )

    MODEL2.optimize()
    return MODEL2.objVal


# Monotonic variant of M2
def OM_1(r, v_len, d):
    v = functionV(v_len)
    MODEL2 = gurobipy.Model()
    x = MODEL2.addVars(range(v_len * v_len), vtype=gurobipy.GRB.CONTINUOUS)

    # Set objective function
    MODEL2.setObjective(gurobipy.quicksum(
        (v[i] - t) * d[i] * gurobipy.quicksum(x[i * v_len + j] * r[i][j] for j in range(v_len))
        for i in range(v_len)), gurobipy.GRB.MAXIMIZE
    )

    # Add constraints
    for i in range(v_len * v_len):
        MODEL2.addConstr(x[i] <= 1)
        MODEL2.addConstr(x[i] >= 0)

    for i in range(v_len):
        for i2 in range(v_len):
            # Maintain dominance constraints
            MODEL2.addConstr(
                gurobipy.quicksum(x[i * v_len + k] * r[i][k] for k in range(v_len)) >=
                gurobipy.quicksum(x[i2 * v_len + k] * r[i][k] for k in range(v_len))
            )
            # Add monotonicity constraints
            if i2 >= 1:
                MODEL2.addConstr(x[i * v_len + i2] >= x[i * v_len + i2 - 1])

    MODEL2.optimize()
    return MODEL2.objVal, [v.x for v in MODEL2.getVars()]


def TMM(r, v_len, d):
    """Threshold Mechanism Model optimization"""
    M3commax = -1.0  # Initialize max common value
    M3maxr = r  # Best R matrix
    M3maxd = d  # Best distribution D
    M3maxAlpha = 0  # Best alpha value
    M3maxObj = -1.0  # Best objective value
    o3 = 0  # Current objective value
    resultx = []  # Result storage

    # Iterate through possible alpha and ones positions
    for alpha in range(0, v_len - 1):
        for ones in range(alpha, v_len):
            # Initialize probability accumulators
            alp = np.zeros((v_len))
            onesList = np.zeros((v_len))
            onesListOverAlp = np.zeros((v_len))

            # Calculate cumulative probabilities
            for i in range(v_len):
                alp[i] = sum(r[i][alpha:v_len])
                onesList[i] = sum(r[i][ones:v_len])
                onesListOverAlp[i] = onesList[i] / alp[i] if alp[i] != 0 else 0

            # Sort and iterate through alpha candidates
            location = np.argsort(onesListOverAlp)
            onesListOverAlpSoted = sorted(onesListOverAlp)

            for alpha_n in onesListOverAlpSoted:
                # Create optimization model
                MODEL3 = gurobipy.Model()
                x3 = MODEL3.addVars(v_len * v_len, vtype=gurobipy.GRB.CONTINUOUS)
                v = functionV(v_len)

                # Set objective function
                MODEL3.setObjective(
                    gurobipy.quicksum(
                        (v[i] - t) * d[i] * gurobipy.quicksum(x3[i * v_len + j] * r[i][j]
                                                              for j in range(v_len))
                        for i in range(v_len)
                    ),
                    gurobipy.GRB.MAXIMIZE
                )

                # Add constraints
                for i in range(v_len * v_len):
                    MODEL3.addConstr(x3[i] <= 1)
                    MODEL3.addConstr(x3[i] >= 0)

                # Apply threshold constraints
                for i in range(v_len):
                    if onesListOverAlp[i] <= alpha_n:
                        # Set x values for alpha region
                        for j in range(alpha, v_len):
                            MODEL3.addConstr(x3[i * v_len + j] == alpha_n)
                        for j in range(alpha):
                            MODEL3.addConstr(x3[i * v_len + j] == 0)
                    else:
                        # Set x values for ones region
                        for j in range(ones, v_len):
                            MODEL3.addConstr(x3[i * v_len + j] == 1)
                        for j in range(ones):
                            MODEL3.addConstr(x3[i * v_len + j] == 0)

                # Optimize and process results
                MODEL3.optimize()
                o3 = MODEL3.objVal

                # Update best solution
                if o3 > M3maxObj:
                    M3maxObj = o3
                    M3maxAlpha = alpha_n
                    resultx = [round(v.x, 5) for v in MODEL3.getVars()]

                MODEL3.terminate()

    # Handle negative objective case
    if M3maxObj < 0:
        M3maxObj = 0
        resultx = [0] * (v_len * v_len)

    return M3maxObj, resultx


def UM_OM(r, v_len, d):
    """Unified Monotonic Optimization Model"""
    v_1 = functionV(v_len)
    v_2 = functionV(v_len)

    # Create optimization model
    MODEL5 = gurobipy.Model()
    x = MODEL5.addVars(2 * v_len * v_len * v_len * v_len, vtype=gurobipy.GRB.CONTINUOUS)
    y = MODEL5.addVars(2 * v_len * v_len, vtype=gurobipy.GRB.CONTINUOUS)

    # Set complex objective function combining two papers' scores
    MODEL5.setObjective(
        gurobipy.quicksum(
            (v_1[i1] - t) * d[i1] * d[i2] *
            gurobipy.quicksum(x[i1 * v_len ** 3 + i2 * v_len ** 2 + j1 * v_len + j2] * r[i1][j1] * r[i2][j2]
                              for j1, j2 in np.ndindex(v_len, v_len))
            for i1, i2 in np.ndindex(v_len, v_len)
        ) +
        gurobipy.quicksum(
            (v_2[i2] - t) * d[i1] * d[i2] *
            gurobipy.quicksum(
                x[v_len ** 4 + i1 * v_len ** 3 + i2 * v_len ** 2 + j1 * v_len + j2] * r[i1][j1] * r[i2][j2]
                for j1, j2 in np.ndindex(v_len, v_len))
            for i1, i2 in np.ndindex(v_len, v_len)
        ),
        gurobipy.GRB.MAXIMIZE
    )

    # Add basic constraints
    for var in [y, x]:
        for i in range(len(var)):
            MODEL5.addConstr(var[i] <= 1)
            MODEL5.addConstr(var[i] >= 0)

    # Add coupling constraints between papers
    for v1, v2, s1, s2 in np.ndindex(v_len, v_len, v_len, v_len):
        idx = v1 * v_len ** 3 + v2 * v_len ** 2 + s1 * v_len + s2
        MODEL5.addConstr(
            y[v1 * v_len + s1] + y[v_len ** 2 + v2 * v_len + s2] <=
            x[idx] + x[v_len ** 4 + idx]
        )
        MODEL5.addConstr(
            y[v1 * v_len + s1] + y[v_len ** 2 + v2 * v_len + s2] >=
            x[idx] + x[v_len ** 4 + idx]
        )

    # Add dominance and monotonicity constraints
    for i in range(v_len):
        for i2 in range(v_len):
            # Current paper constraints
            MODEL5.addConstr(
                gurobipy.quicksum(y[i * v_len + k] * r[i][k] for k in range(v_len)) >=
                gurobipy.quicksum(y[i2 * v_len + k] * r[i][k] for k in range(v_len))
            )
            # Other paper constraints
            MODEL5.addConstr(
                gurobipy.quicksum(y[v_len ** 2 + i * v_len + k] * r[i][k] for k in range(v_len)) >=
                gurobipy.quicksum(y[v_len ** 2 + i2 * v_len + k] * r[i][k] for k in range(v_len))
            )
            # Monotonicity constraints
            if i2 >= 1:
                MODEL5.addConstr(y[i * v_len + i2] >= y[i * v_len + i2 - 1])
                MODEL5.addConstr(y[v_len ** 2 + i * v_len + i2] >= y[v_len ** 2 + i * v_len + i2 - 1])

    MODEL5.optimize()
    return MODEL5.objVal, [v.x for v in MODEL5.getVars()]


def UM_TM(r, v_len, d, x3):
    """Unified Threshold Mechanism Model"""
    v_1 = functionV(v_len)
    v_2 = functionV(v_len)

    # Create optimization model with predefined x3 values
    MODEL5 = gurobipy.Model()
    x = MODEL5.addVars(2 * v_len ** 4, vtype=gurobipy.GRB.CONTINUOUS)
    y = x3  # Use precomputed x3 values

    # Set objective function similar to UM_OM
    MODEL5.setObjective(
        gurobipy.quicksum(
            (v_1[i1] - t) * d[i1] * d[i2] *
            gurobipy.quicksum(x[i1 * v_len ** 3 + i2 * v_len ** 2 + j1 * v_len + j2] * r[i1][j1] * r[i2][j2]
                              for j1, j2 in np.ndindex(v_len, v_len))
            for i1, i2 in np.ndindex(v_len, v_len)
        ) +
        gurobipy.quicksum(
            (v_2[i2] - t) * d[i1] * d[i2] *
            gurobipy.quicksum(
                x[v_len ** 4 + i1 * v_len ** 3 + i2 * v_len ** 2 + j1 * v_len + j2] * r[i1][j1] * r[i2][j2]
                for j1, j2 in np.ndindex(v_len, v_len))
            for i1, i2 in np.ndindex(v_len, v_len)
        ),
        gurobipy.GRB.MAXIMIZE
    )

    # Add coupling constraints
    for v1, v2, s1, s2 in np.ndindex(v_len, v_len, v_len, v_len):
        idx = v1 * v_len ** 3 + v2 * v_len ** 2 + s1 * v_len + s2
        MODEL5.addConstr(
            y[v1 * v_len + s1] + y[v2 * v_len + s2] <=
            x[idx] + x[v_len ** 4 + idx]
        )
        MODEL5.addConstr(
            y[v1 * v_len + s1] + y[v2 * v_len + s2] >=
            x[idx] + x[v_len ** 4 + idx]
        )

    MODEL5.optimize()
    return MODEL5.objVal, [v.x for v in MODEL5.getVars()]


def OM_2(r, v_len, d):
    """Optimization Model 2 with Monotonic Constraints"""
    commax = 0  # Common maximum value
    obj0 = 0  # Initial objective value
    gt1 = 0  # Counter

    # Main optimization loop
    for run in range(1):
        v_1 = functionV(v_len)
        v_2 = functionV(v_len)

        # Create dual-paper optimization model
        MODEL4 = gurobipy.Model()
        x = MODEL4.addVars(v_len ** 4, vtype=gurobipy.GRB.CONTINUOUS)

        # Set complex dual-paper objective function
        MODEL4.setObjective(
            gurobipy.quicksum(
                (v_1[i1] - t) * d[i1] * d[i2] *
                gurobipy.quicksum(x[i1 * v_len ** 3 + i2 * v_len ** 2 + j1 * v_len + j2] * r[i1][j1] * r[i2][j2]
                                  for j1, j2 in np.ndindex(v_len, v_len))
                for i1, i2 in np.ndindex(v_len, v_len)
            ) +
            gurobipy.quicksum(
                (v_2[i2] - t) * d[i1] * d[i2] *
                gurobipy.quicksum(x[i2 * v_len ** 3 + i1 * v_len ** 2 + j2 * v_len + j1] * r[i1][j1] * r[i2][j2]
                                  for j1, j2 in np.ndindex(v_len, v_len))
                for i1, i2 in np.ndindex(v_len, v_len)
            ),
            gurobipy.GRB.MAXIMIZE
        )

        # Add basic constraints
        for i in range(v_len ** 4):
            MODEL4.addConstr(x[i] <= 1)
            MODEL4.addConstr(x[i] >= 0)

        # Add dominance constraints
        for i1, i2 in np.ndindex(v_len, v_len):
            for k1, k2 in np.ndindex(v_len, v_len):
                # Current paper combination
                current_sum = gurobipy.quicksum(
                    x[i1 * v_len ** 3 + i2 * v_len ** 2 + j1 * v_len + j2] * r[i1][j1] * r[i2][j2] +
                    x[i2 * v_len ** 3 + i1 * v_len ** 2 + j2 * v_len + j1] * r[i1][j1] * r[i2][j2]
                    for j1, j2 in np.ndindex(v_len, v_len)
                )

                # Comparison paper combination
                comp_sum = gurobipy.quicksum(
                    x[k1 * v_len ** 3 + k2 * v_len ** 2 + j1 * v_len + j2] * r[i1][j1] * r[i2][j2] +
                    x[k2 * v_len ** 3 + k1 * v_len ** 2 + j2 * v_len + j1] * r[i1][j1] * r[i2][j2]
                    for j1, j2 in np.ndindex(v_len, v_len)
                )
                MODEL4.addConstr(current_sum >= comp_sum)

        # Add monotonicity constraints
        for v1, v2, s1, s2 in np.ndindex(v_len, v_len, v_len, v_len):
            idx = v1 * v_len ** 3 + v2 * v_len ** 2 + s1 * v_len + s2
            if s1 > 0:
                MODEL4.addConstr(x[idx] >= x[idx - v_len])
            if s2 > 0:
                MODEL4.addConstr(x[idx] >= x[idx - 1])

        MODEL4.optimize()
        return MODEL4.objVal, [v.x for v in MODEL4.getVars()]


def OM_3(r, v_len, d):
    """Optimization Model 3 for triple paper submission scenario"""
    commax = 0  # Common maximum tracking
    obj0 = 0  # Initial objective value
    gt1 = 0  # General counter

    for _ in range(1):  # Single run configuration
        # Initialize value arrays for three papers
        v_1 = functionV(v_len)
        v_2 = functionV(v_len)
        v_3 = functionV(v_len)

        # Create optimization model
        MODEL4 = gurobipy.Model()

        # Create 6-dimensional decision variables (v1,v2,v3,s1,s2,s3)
        x = MODEL4.addVars(v_len ** 6, vtype=gurobipy.GRB.CONTINUOUS)

        # Initialize identical distributions for three papers
        d_1 = d
        d_2 = d
        d_3 = d

        # Set complex objective function for three papers
        MODEL4.setObjective(
            gurobipy.quicksum(
                (v_1[i1] - t) * d_1[i1] * d_2[i2] * d_3[i3] *
                gurobipy.quicksum(
                    x[i1 * v_len ** 5 + i2 * v_len ** 4 + i3 * v_len ** 3 +
                      j1 * v_len ** 2 + j2 * v_len + j3] *
                    r[i1][j1] * r[i2][j2] * r[i3][j3]
                    for j1, j2, j3 in np.ndindex(v_len, v_len, v_len)
                )
                for i1, i2, i3 in np.ndindex(v_len, v_len, v_len)
            ) +
            gurobipy.quicksum(  # Symmetric terms for paper 2 and 3
                (v_2[i2] - t) * d_1[i1] * d_2[i2] * d_3[i3] *
                gurobipy.quicksum(
                    x[i1 * v_len ** 5 + i2 * v_len ** 4 + i3 * v_len ** 3 +
                      j1 * v_len ** 2 + j2 * v_len + j3] *
                    r[i1][j1] * r[i2][j2] * r[i3][j3]
                    for j1, j2, j3 in np.ndindex(v_len, v_len, v_len)
                )
                for i1, i2, i3 in np.ndindex(v_len, v_len, v_len)
            ) +
            gurobipy.quicksum(
                (v_3[i3] - t) * d_1[i1] * d_2[i2] * d_3[i3] *
                gurobipy.quicksum(
                    x[i1 * v_len ** 5 + i2 * v_len ** 4 + i3 * v_len ** 3 +
                      j1 * v_len ** 2 + j2 * v_len + j3] *
                    r[i1][j1] * r[i2][j2] * r[i3][j3]
                    for j1, j2, j3 in np.ndindex(v_len, v_len, v_len)
                )
                for i1, i2, i3 in np.ndindex(v_len, v_len, v_len)
            ),
            gurobipy.GRB.MAXIMIZE
        )

        # Add basic variable constraints
        for i in range(v_len ** 6):
            MODEL4.addConstr(x[i] <= 1)
            MODEL4.addConstr(x[i] >= 0)

        # Add dominance constraints for triple comparison
        for i1, i2, i3 in np.ndindex(v_len, v_len, v_len):
            for k1, k2, k3 in np.ndindex(v_len, v_len, v_len):
                current_sum = gurobipy.quicksum(
                    x[i1 * v_len ** 5 + i2 * v_len ** 4 + i3 * v_len ** 3 +
                      j1 * v_len ** 2 + j2 * v_len + j3] *
                    r[i1][j1] * r[i2][j2] * r[i3][j3]
                    for j1, j2, j3 in np.ndindex(v_len, v_len, v_len)
                )

                comp_sum = gurobipy.quicksum(
                    x[k1 * v_len ** 5 + k2 * v_len ** 4 + k3 * v_len ** 3 +
                      j1 * v_len ** 2 + j2 * v_len + j3] *
                    r[i1][j1] * r[i2][j2] * r[i3][j3]
                    for j1, j2, j3 in np.ndindex(v_len, v_len, v_len)
                )
                MODEL4.addConstr(current_sum >= comp_sum)

        # Add monotonicity constraints for all dimensions
        for v1, v2, v3, s1, s2, s3 in np.ndindex(v_len, v_len, v_len, v_len, v_len, v_len):
            idx = v1 * v_len ** 5 + v2 * v_len ** 4 + v3 * v_len ** 3 + s1 * v_len ** 2 + s2 * v_len + s3
            if s1 > 0:
                MODEL4.addConstr(x[idx] >= x[idx - v_len ** 2])
            if s2 > 0:
                MODEL4.addConstr(x[idx] >= x[idx - v_len])
            if s3 > 0:
                MODEL4.addConstr(x[idx] >= x[idx - 1])

        MODEL4.optimize()
        return MODEL4.objVal, [round(v.x, 5) for v in MODEL4.getVars()]


def M10_paperRanking(r, v_len, d):
    """Paper ranking mechanism based on expected value comparisons"""
    v = functionV(v_len)

    # Initialize comparison matrices
    As = np.zeros((v_len, v_len))  # A < B
    Ae = np.zeros((v_len, v_len))  # A = B
    Ag = np.zeros((v_len, v_len))  # A > B
    Bs = np.zeros((v_len, v_len))
    Be = np.zeros((v_len, v_len))
    Bg = np.zeros((v_len, v_len))

    # Calculate expected value matrices
    for s1, s2 in np.ndindex(v_len, v_len):
        # Initialize accumulators
        sum_lt, sum_eq, sum_gt = 0, 0, 0
        total_lt, total_eq, total_gt = 0, 0, 0

        # Calculate expected values for all pairs
        for v1, v2 in np.ndindex(v_len, v_len):
            prob = d[v1] * d[v2] * r[v1][s1] * r[v2][s2]
            if v1 < v2:
                sum_lt += v[v1] * prob
                total_lt += prob
            elif v1 == v2:
                sum_eq += v[v1] * prob
                total_eq += prob
            else:
                sum_gt += v[v1] * prob
                total_gt += prob

        # Store normalized values
        As[s1, s2] = sum_lt / total_lt if total_lt != 0 else 0
        Ae[s1, s2] = sum_eq / total_eq if total_eq != 0 else 0
        Ag[s1, s2] = sum_gt / total_gt if total_gt != 0 else 0

    # Thresholding at 0.5 for decision boundaries
    threshold_matrices = [As, Ae, Ag, Bs, Be, Bg]
    for mat in threshold_matrices:
        mat[mat >= 0.5] = 1
        mat[mat < 0.5] = 0

    # Calculate final ranking probabilities
    x1g = np.zeros((v_len, v_len))
    x1e = np.zeros((v_len, v_len))
    x1s = np.zeros((v_len, v_len))

    for v1, v2 in np.ndindex(v_len, v_len):
        for s1, s2 in np.ndindex(v_len, v_len):
            prob = r[v1][s1] * r[v2][s2]
            x1g[v1, v2] += prob * (Ag[s1, s2] + Bs[s1, s2])
            x1e[v1, v2] += prob * (Ae[s1, s2] + Be[s1, s2])
            x1s[v1, v2] += prob * (As[s1, s2] + Bg[s1, s2])

    return x1g, x1e, x1s



v_len = 7

x1v1v2 = np.zeros((v_len, v_len))
x2v1v2 = np.zeros((v_len, v_len))
x1v1 = np.zeros(v_len)
x2v2 = np.zeros(v_len)

# d = normalDistD(0.3, 0.25, v_len)
# r = normalDistR(0.25,v_len)
# d = [0.4,0.5,0.1]
# d = geometricDistribution(0.6, int(v_len / 2), v_len)
v = functionV(v_len)
v_1 = v


# Main execution block
for count in range(1):
    # r = normalDistR((count+1)/1000,v_len)
    '''
    d = [0.0197, 0.0493, 0.1232, 0.6158, 0.1232, 0.0493, 0.0197]
    r = [[0.7508, 0.1502, 0.0601, 0.024, 0.0096, 0.0038, 0.0015],
         [0.1307, 0.6536, 0.1307, 0.0523, 0.0209, 0.0084, 0.0033],
         [0.0499, 0.1246, 0.6231, 0.1246, 0.0499, 0.0199, 0.008],
         [0.0197, 0.0493, 0.1232, 0.6158, 0.1232, 0.0493, 0.0197],
         [0.008, 0.0199, 0.0499, 0.1246, 0.6231, 0.1246, 0.0499],
         [0.0033, 0.0084, 0.0209, 0.0523, 0.1307, 0.6536, 0.1307],
         [0.0015, 0.0038, 0.0096, 0.024, 0.0601, 0.1502, 0.7508]]
    '''
    # r = singlePeakR(v_len)
    d = logNormalDistribution(0.3, 0.25, v_len)
    r = logNormalDistR(0.25, v_len)

    # r = geometricDistR(0.6, v_len)
    # d = geometricDistribution(0.6, int(v_len / 2), v_len)
    # r = geometricDistR(0.6, v_len)

    for i in range(v_len):
        d[i] = round(d[i], 4)
        for j in range(v_len):
            r[i][j] = round(r[i][j], 4)

    print(d)
    print(r)

    # Execute various mechanisms
    o1, x1 = SO(r, v_len, d)
    o2, x2 = OM_1(r, v_len, d)
    o3, x3 = TMM(r, v_len, d)
    o4, x4 = OM_2(r, v_len, d)
    o5, x5 = UM_OM(r, v_len, d)
    o5_3, x5_3 = UM_TM(r, v_len, d, x3)
    om_3, xom_3 = OM_3(r, v_len, d)

    # Print results
    j = 0
    print("Objective for SO:", o1)
    print("SO result:")
    for val in x1:
        print('%10s' % round(val, 5), end="")
        print(",", end="")
        if j == v_len - 1:
            print(" ")
            j = 0
        else:
            j += 1

    j = 0
    print("Objective for M2:", o2)
    print("M2 result:")
    for val in x2:
        print('%10s' % round(val, 5), end="")
        print(",", end="")
        if j == v_len - 1:
            print(" ")
            j = 0
        else:
            j += 1

    j = 0
    print("Objective for TMM:", o3)
    print("TMM result:")
    for val in x3:
        print('%10s' % round(val, 5), end="")
        print(",", end="")
        if j == v_len - 1:
            print(" ")
            j = 0
        else:
            j += 1

    print("M4 Objective:", o4)
    print("M4 result:")
    v1 = 0
    v2 = 0
    j = 0
    j2 = 0
    paper = 1

    # Additional printing logic for M4 results...
    # [Remaining print statements follow similar translation pattern]

    # Final results summary
    print("SO Objective:", o1)
    print("OM_1 Objective:", o2)
    print("TMM Objective:", o3)
    print("OM_2 Objective:", o4)
    print("UM_OM Objective:", o5)
    print("UM_TMM Objective:", o5_3)

    print('d(v):', d)
    print("r(v,s):")
    print(r)

    # Data logging
    with open('log.txt', 'a') as f:
        f.write(f"{np.round(o1, 4)} {np.round(o2, 4)} {np.round(o3, 4)} "
                f"{np.round(o4, 4)} {np.round(o5, 4)} {np.round(o5_3, 4)} "
                f"{np.round(om_3, 4)}\n")

    print("Round:", count)
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def PeakBetween(path='data2.csv'):
    """
    Plot and compare peak values between different methods.

    Args:
        path (str): Path to the CSV file containing data
    """
    # Read data from CSV file
    data = pd.read_csv(path, sep=',', header=None, names=['M1', 'M2', 'M3', 'M4', 'M5_2', 'M5_3'])
    length = len(data)

    # Plot each method's data with different styles
    M1, = plt.plot(0.5 + np.arange(0, length) / 10000, data['M1'], color='blue', lw=4, ls='-.')
    M2, = plt.plot(0.5 + np.arange(0, length) / 10000, data['M2'], color='deeppink', lw=8, ls=':')
    M3, = plt.plot(0.5 + np.arange(0, length) / 10000, data['M3'], color='orange', lw=4, ls='--')
    M4, = plt.plot(0.5 + np.arange(0, length) / 10000, data['M4'], color='red', lw=4, ls='-')
    M5_2, = plt.plot(0.5 + np.arange(0, length) / 10000, data['M5_2'], color='dodgerblue', lw=4, ls='-')
    M5_3, = plt.plot(0.5 + np.arange(0, length) / 10000, data['M5_3'], color='plum', lw=4, ls='-')

    # Configure axis labels and ticks
    plt.yticks(size=25)
    plt.xticks([0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80], size=25)
    plt.ylabel('Objective', fontfamily='Times New Roman', fontsize=30, fontweight='bold')
    plt.xlabel('Peak Value of r(v,s)', fontfamily='Times New Roman', fontsize=30, fontweight='bold')
    plt.ylim((0, 0.05))

    # Configure plot appearance
    ax = plt.gca()
    ax.spines['top'].set_visible(False)
    plt.grid(axis='y')

    # Create legend
    legend_font = {'family': 'Times New Roman', 'weight': 'bold', 'size': 25}
    plt.legend([M1, M2, M3, M4, M5_2, M5_3],
               ["SO", 'OM$_{1}$', 'TM', "OM$_{2}$", "UM$_{OPT}$", "UM$_{TM}$"],
               loc='upper left', prop=legend_font)

    # Save and display plot
    plt.savefig("peakbetween.png", dpi=500, bbox_inches='tight')
    plt.show()


def Peak(path='data3.csv'):
    """
    Plot and compare paper acceptance rates across different peak values.

    Args:
        path (str): Path to the CSV file containing data
    """
    data = pd.read_csv(path, sep=',', header=None, names=['M1', 'M2', 'M3', 'M4', 'M5_2', 'M5_3'])
    length = len(data)

    # Plot each method's data with different styles
    M1, = plt.plot(np.arange(0, length) / 6, data['M1'], color='blue', lw=4, ls='-.')
    M2, = plt.plot(np.arange(0, length) / 6, data['M2'], color='deeppink', lw=8, ls=':')
    M3, = plt.plot(np.arange(0, length) / 6, data['M3'], color='orange', lw=4, ls='--')
    M4, = plt.plot(np.arange(0, length) / 6, data['M4'], color='red', lw=4, ls='-')
    M5_2, = plt.plot(np.arange(0, length) / 6, data['M5_2'], color='dodgerblue', lw=4, ls='-')
    M5_3, = plt.plot(np.arange(0, length) / 6, data['M5_3'], color='plum', lw=4, ls='-')

    # Configure axis labels and ticks
    plt.xticks([0.0, round(1 / 6, 2), round(2 / 6, 2), round(3 / 6, 2),
                round(4 / 6, 2), round(5 / 6, 2), 1], size=25)
    plt.yticks(size=25)
    plt.ylabel('Paper Accept Rate', fontfamily='Times New Roman', fontsize=30, fontweight='bold')
    plt.xlabel('Value of Paper', fontfamily='Times New Roman', fontsize=30, fontweight='bold')
    plt.ylim((0, 1.0))

    # Configure plot appearance
    ax = plt.gca()
    ax.spines['top'].set_visible(False)
    plt.grid(axis='y')

    # Create legend
    legend_font = {'family': 'Times New Roman', 'weight': 'bold', 'size': 25}
    plt.legend([M1, M2, M3, M4, M5_2, M5_3],
               ["SO", 'OM$_{1}$', 'TM', "OM$_{2}$", "UMOPT", "UM$_{TM}$"],
               loc='upper left', prop=legend_font)

    # Save and display plot
    plt.savefig("peak.png", dpi=500, bbox_inches='tight')
    plt.show()


def VarianceBetween(path='data.csv'):
    """
    Plot and compare variance between different methods.

    Args:
        path (str): Path to the CSV file containing data
    """
    data = pd.read_csv(path, sep=',', header=None, names=['M1', 'M2', 'M3', 'M4', 'M5_2', 'M5_3'])
    length = len(data)

    # Plot each method's data with different styles
    M1, = plt.plot(np.arange(0, length) / 1000, data['M1'], color='blue', lw=4, ls='-.')
    M2, = plt.plot(np.arange(0, length) / 1000, data['M2'], color='deeppink', lw=8, ls=':')
    M3, = plt.plot(np.arange(0, length) / 1000, data['M3'], color='orange', lw=4, ls='--')
    M4, = plt.plot(np.arange(0, length) / 1000, data['M4'], color='red', lw=4, ls='-')
    M5_2, = plt.plot(np.arange(0, length) / 1000, data['M5_2'], color='dodgerblue', lw=4, ls='-')
    M5_3, = plt.plot(np.arange(0, length) / 1000, data['M5_3'], color='plum', lw=4, ls='-')

    # Configure axis labels and ticks
    plt.xticks([0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6], size=25)
    plt.yticks(size=25)
    plt.ylabel('Objective', fontfamily='Times New Roman', fontsize=30, fontweight='bold')
    plt.xlabel('Variance of r(v,s)', fontfamily='Times New Roman', fontsize=30, fontweight='bold')
    plt.ylim((0, 0.06))

    # Configure plot appearance
    ax = plt.gca()
    ax.spines['top'].set_visible(False)
    plt.grid(axis='y')

    # Create legend
    legend_font = {'family': 'Times New Roman', 'weight': 'bold', 'size': 25}
    plt.legend([M1, M2, M3, M4, M5_2, M5_3],
               ["SO", 'OM$_{1}$', 'TM', "OM$_{2}$", "UMOPT", "UM$_{TM}$"],
               loc='upper right', prop=legend_font)

    # Save and display plot
    plt.savefig("variancebewteen.png", dpi=500, bbox_inches='tight')
    plt.show()


def Variance(path='data1.csv'):
    """
    Plot and compare variance across different paper values.

    Args:
        path (str): Path to the CSV file containing data
    """
    data = pd.read_csv(path, sep=',', header=None, names=['M1', 'M2', 'M3', 'M4', 'M5_2', 'M5_3'])
    length = len(data)

    # Plot each method's data with different styles
    M1, = plt.plot(np.arange(0, length) / 6, data['M1'], color='blue', lw=4, ls='-.')
    M2, = plt.plot(np.arange(0, length) / 6, data['M2'], color='deeppink', lw=8, ls=':')
    M3, = plt.plot(np.arange(0, length) / 6, data['M3'], color='orange', lw=4, ls='--')
    M4, = plt.plot(np.arange(0, length) / 6, data['M4'], color='red', lw=4, ls='-')
    M5_2, = plt.plot(np.arange(0, length) / 6, data['M5_2'], color='dodgerblue', lw=4, ls='-')
    M5_3, = plt.plot(np.arange(0, length) / 6, data['M5_3'], color='plum', lw=4, ls='-')

    # Configure axis labels and ticks
    plt.xticks([0.0, round(1 / 6, 2), round(2 / 6, 2), round(3 / 6, 2),
                round(4 / 6, 2), round(5 / 6, 2), 1], size=25)
    plt.yticks(size=25)
    plt.ylabel('Paper Accept Rate', fontfamily='Times New Roman', fontsize=30, fontweight='bold')
    plt.xlabel('Value of Paper', fontfamily='Times New Roman', fontsize=30, fontweight='bold')
    plt.ylim((0, 1.0))

    # Configure plot appearance
    ax = plt.gca()
    ax.spines['top'].set_visible(False)
    plt.grid(axis='y')

    # Create legend
    legend_font = {'family': 'Times New Roman', 'weight': 'bold', 'size': 25}
    plt.legend([M1, M2, M3, M4, M5_2, M5_3],
               ["SO", 'OM$_{1}$', 'TM', "OM$_{2}$", "UMOPT", "UM$_{TM}$"],
               loc='upper left', prop=legend_font)

    # Save and display plot
    plt.savefig("variance.png", dpi=500, bbox_inches='tight')
    plt.show()

# Function calls
#PeakBetween()
#Peak()
Variance()
#VarianceBetween()